#include<windows.h>
#ifdef __APPLE__
#include <GLUT/glut.h>
#else
#include <GL/glut.h>
#endif

#include <stdlib.h>
#include <math.h>
#define PI 3.1416



float p,r=-1.0;
float a,b=0;
float q=1;


static float	tx	=  0.0;
static float	ty	=  0.0;
void init()
{
    glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
    glOrtho(-1,1,-1,1,-1,1);


}

void circle(float radius_x, float radius_y)
{
	int i=0;
	float angle = 0.0;

	glBegin(GL_POLYGON);

		for(i = 0; i < 100; i++)
		{
			angle = 2 * PI * i / 100;
			glVertex2f (cos(angle) * radius_x, sin(angle) * radius_y);
		}

	glEnd();
}

void draw_circle(float x, float y, float radius)
{
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glLoadIdentity();
    glTranslatef(x, y, 0.0f);
    static const int circle_points = 100;
    static const float angle = 2.0f * 3.1416f / circle_points;

    // this code (mostly) copied from question:
    glBegin(GL_POLYGON);
    double angle1=0.0;
    glVertex2d(radius * cos(0.0) , radius * sin(0.0));
    int i;
    for (i=0; i<circle_points; i++)
    {
        glVertex2d(radius * cos(angle1), radius *sin(angle1));
        angle1 += angle;
    }
    glEnd();
    glPopMatrix();
}

void myDisplay()
{
    if(p<=1.9)
        p=p+0.0002;

    else
        p=-1;

    if(r<=1.9)
        r=r+0.0001;

    else
        r=-1;

    if(q>=-1.9)
        q=q-0.0001;

    else
        q=1;

    if(a<=0.20)
        a=a+0.0004;

    else
        a=0;
    if(b<=0.003)
        b=b+0.0001;

    else
        b=0;
    glutPostRedisplay();

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

//------------------background
    glBegin(GL_QUADS);
//white
    glColor3f(1,1,1);
    glVertex2f(-1,0.4);
    glVertex2f(1,0.4);
//blue
    glColor3f(0,0.96,1);
    glVertex2f(1,1);
    glVertex2f(-1,1);
    glEnd();

//----------------------road

    glColor3f(0.6,0.8,0.6);
    draw_circle(-0.95,0.41,0.05);
    draw_circle(-0.91,0.41,0.06);
    draw_circle(-0.87,0.41,0.03);
    draw_circle(-0.82,0.41,0.05);
    draw_circle(-0.78,0.41,0.05);
    draw_circle(-1,0.41,0.05);
    draw_circle(-0.72,0.41,0.08);
    draw_circle(-0.52,0.41,0.05);
    draw_circle(-0.43,0.41,0.07);
    draw_circle(-0.33,0.41,0.09);
    draw_circle(-0.22,0.41,0.08);

    draw_circle(0.95,0.41,0.05);
    draw_circle(0.91,0.41,0.06);
    draw_circle(0.87,0.41,0.03);
    draw_circle(0.82,0.41,0.05);
    draw_circle(0.78,0.41,0.05);
    draw_circle(1,0.41,0.05);
    draw_circle(0.72,0.41,0.08);
    draw_circle(0.52,0.41,0.05);
    draw_circle(0.43,0.41,0.07);
    draw_circle(0.33,0.41,0.09);
    draw_circle(0.22,0.41,0.08);
    draw_circle(0.0,0.41,0.1);


    glBegin(GL_QUADS);
//grey
    glColor3f(0.49,0.49,0.49);
    glVertex2f(-1,0.1);
    glVertex2f(1,0.1);
    glVertex2f(1,0.4);
    glVertex2f(-1,0.4);
    glEnd();
    glBegin(GL_QUADS);
//white
    glColor3f(1,1,1);
    glVertex2f(-0.7,0.23);
    glVertex2f(-0.5,0.23);
    glVertex2f(-0.5,0.27);
    glVertex2f(-0.7,0.27);
    glEnd();
    glBegin(GL_QUADS);
//white
    glColor3f(1,1,1);
    glVertex2f(0.0,0.23);
    glVertex2f(0.2,0.23);
    glVertex2f(0.2,0.27);
    glVertex2f(0.0,0.27);
    glEnd();
    glBegin(GL_QUADS);
//white
    glColor3f(1,1,1);
    glVertex2f(0.7,0.23);
    glVertex2f(0.9,0.23);
    glVertex2f(0.9,0.27);
    glVertex2f(0.7,0.27);
    glEnd();

    glColor3f(0.4,0.8,0);
    draw_circle(-0.85,0.16,0.05);
    draw_circle(-0.81,0.16,0.06);
    draw_circle(-0.77,0.16,0.03);
    draw_circle(-0.72,0.16,0.05);
    draw_circle(-0.68,0.16,0.05);
    draw_circle(-1,0.16,0.05);
    draw_circle(-0.62,0.16,0.08);
    draw_circle(-0.42,0.16,0.05);
    draw_circle(-0.33,0.16,0.07);
    draw_circle(-0.23,0.16,0.09);
    draw_circle(-0.12,0.16,0.08);


    draw_circle(0.85,0.16,0.05);
    draw_circle(0.81,0.16,0.06);
    draw_circle(0.77,0.16,0.03);
    draw_circle(0.72,0.16,0.05);
    draw_circle(0.68,0.16,0.05);
    draw_circle(1,0.16,0.05);
    draw_circle(0.62,0.16,0.08);
    draw_circle(0.42,0.16,0.05);
    draw_circle(0.53,0.16,0.07);
    draw_circle(0.23,0.16,0.09);
    draw_circle(0.12,0.16,0.08);
    draw_circle(0.0,0.16,0.1);

    glColor3f(0.6,0.8,0);
    draw_circle(-0.95,0.1,0.05);
    draw_circle(-0.91,0.1,0.06);
    draw_circle(-0.87,0.1,0.03);
    draw_circle(-0.82,0.1,0.05);
    draw_circle(-0.78,0.1,0.05);
    draw_circle(-1,0.1,0.05);
    draw_circle(-0.72,0.1,0.08);
    draw_circle(-0.52,0.1,0.05);
    draw_circle(-0.43,0.1,0.07);
    draw_circle(-0.33,0.1,0.09);
    draw_circle(-0.22,0.1,0.08);

    draw_circle(0.95,0.1,0.05);
    draw_circle(0.91,0.1,0.06);
    draw_circle(0.87,0.1,0.03);
    draw_circle(0.82,0.1,0.05);
    draw_circle(0.78,0.1,0.05);
    draw_circle(1,0.1,0.05);
    draw_circle(0.72,0.1,0.08);
    draw_circle(0.52,0.1,0.05);
    draw_circle(0.43,0.1,0.07);
    draw_circle(0.33,0.1,0.09);
    draw_circle(0.22,0.1,0.08);
    draw_circle(0.0,0.1,0.1);

//------------------------Steel boundary
    glBegin(GL_LINE_LOOP);
//grey
    glColor3f(0.41,0.41,0.41);
    glVertex2f(-1,0.1);
    glVertex2f(1,0.1);
    glEnd();
    glBegin(GL_LINE_LOOP);
//grey
    glColor3f(0.41,0.41,0.41);
    glVertex2f(-1,0.175);
    glVertex2f(1,0.175);
    glEnd();
    glBegin(GL_LINE_LOOP);
//grey
    glColor3f(0.41,0.41,0.41);
    glVertex2f(-1,0.15);
    glVertex2f(1,0.15);
    glEnd();
    glBegin(GL_LINE_LOOP);
//grey
    glColor3f(0.41,0.41,0.41);
    glVertex2f(-1,0.125);
    glVertex2f(1,0.125);
    glEnd();
    glBegin(GL_LINE_LOOP);
//grey
    glColor3f(0.41,0.41,0.41);
    glVertex2f(-1,0.2);
    glVertex2f(1,0.2);
    glEnd();

    glBegin(GL_QUADS);
//grey
    glColor3f(0.41,0.41,0.41);
    glVertex2f(-0.8,0.1);
    glVertex2f(-0.75,0.1);
    glVertex2f(-0.75,0.2);
    glVertex2f(-0.8,0.2);
    glEnd();

    glBegin(GL_QUADS);
//grey
    glColor3f(0.41,0.41,0.41);
    glVertex2f(-0.5,0.1);
    glVertex2f(-0.45,0.1);
    glVertex2f(-0.45,0.2);
    glVertex2f(-0.5,0.2);
    glEnd();

    glBegin(GL_QUADS);
//grey
    glColor3f(0.41,0.41,0.41);
    glVertex2f(-0.2,0.1);
    glVertex2f(-0.15,0.1);
    glVertex2f(-0.15,0.2);
    glVertex2f(-0.2,0.2);
    glEnd();

    glBegin(GL_QUADS);
//grey
    glColor3f(0.41,0.41,0.41);
    glVertex2f(0.1,0.1);
    glVertex2f(0.15,0.1);
    glVertex2f(0.15,0.2);
    glVertex2f(0.1,0.2);
    glEnd();

    glBegin(GL_QUADS);
//grey
    glColor3f(0.41,0.41,0.41);
    glVertex2f(0.4,0.1);
    glVertex2f(0.45,0.1);
    glVertex2f(0.45,0.2);
    glVertex2f(0.4,0.2);
    glEnd();

    glBegin(GL_QUADS);
//grey
    glColor3f(0.41,0.41,0.41);
    glVertex2f(0.7,0.1);
    glVertex2f(0.75,0.1);
    glVertex2f(0.75,0.2);
    glVertex2f(0.7,0.2);
    glEnd();

    glBegin(GL_QUADS);
//grey
    glColor3f(0.41,0.41,0.41);
    glVertex2f(-1,0.1);
    glVertex2f(1,0.1);
    glVertex2f(1,0.11);
    glVertex2f(-1,0.11);
    glEnd();

    glBegin(GL_QUADS);
//grey
    glColor3f(0.41,0.41,0.41);
    glVertex2f(-1,0.2);
    glVertex2f(1,0.2);
    glVertex2f(1,0.21);
    glVertex2f(-1,0.21);
    glEnd();


//-----------------grass
    glBegin(GL_QUADS);
//peach
    glColor3f(0.8,0.58,0.04);
    glVertex2f(-1,0.1);
    glVertex2f(1,0.1);
    glColor3f(1,0.84,0.0);
    glVertex2f(1,-0.25);
    glVertex2f(-1,-0.25);
    glEnd();
    glColor3f(1,0.85,0.72);

    glColor3f(0.4,0.8,0);
    draw_circle(-0.85,-0.2,0.05);
    draw_circle(-0.81,-0.2,0.06);
    draw_circle(-0.77,-0.2,0.03);
    draw_circle(-0.72,-0.2,0.05);
    draw_circle(-0.68,-0.2,0.05);
    draw_circle(-1,-0.2,0.05);
    draw_circle(-0.62,-0.2,0.08);
    draw_circle(-0.42,-0.2,0.05);
    draw_circle(-0.33,-0.2,0.07);
    draw_circle(-0.23,-0.2,0.09);
    draw_circle(-0.12,-0.2,0.08);


    draw_circle(0.85,-0.2,0.05);
    draw_circle(0.81,-0.2,0.06);
    draw_circle(0.77,-0.2,0.03);
    draw_circle(0.72,-0.2,0.05);
    draw_circle(0.68,-0.2,0.05);
    draw_circle(1,-0.2,0.05);
    draw_circle(0.62,-0.2,0.08);
    draw_circle(0.42,-0.2,0.05);
    draw_circle(0.53,-0.2,0.07);
    draw_circle(0.23,-0.2,0.09);
    draw_circle(0.12,-0.2,0.08);
    draw_circle(0.0,-0.2,0.1);

    glColor3f(0.6,0.8,0);
    draw_circle(-0.95,-0.25,0.05);
    draw_circle(-0.91,-0.25,0.06);
    draw_circle(-0.87,-0.25,0.03);
    draw_circle(-0.82,-0.25,0.05);
    draw_circle(-0.78,-0.25,0.05);
    draw_circle(-1,-0.25,0.05);
    draw_circle(-0.72,-0.25,0.08);
    draw_circle(-0.52,-0.25,0.05);
    draw_circle(-0.43,-0.25,0.07);
    draw_circle(-0.33,-0.25,0.09);
    draw_circle(-0.22,-0.25,0.08);

    draw_circle(0.95,-0.25,0.05);
    draw_circle(0.91,-0.25,0.06);
    draw_circle(0.87,-0.25,0.03);
    draw_circle(0.82,-0.25,0.05);
    draw_circle(0.78,-0.25,0.05);
    draw_circle(1,-0.25,0.05);
    draw_circle(0.72,-0.25,0.08);
    draw_circle(0.52,-0.25,0.05);
    draw_circle(0.43,-0.25,0.07);
    draw_circle(0.33,-0.25,0.09);
    draw_circle(0.22,-0.25,0.08);
    draw_circle(0.0,-0.25,0.1);

    glBegin(GL_QUADS);

//green
    glColor3f(0,0.80,0.0);
    glVertex2f(-1,-0.25);
    glColor3f(0,0.90,0.0);
    glVertex2f(1,-0.25);
    glColor3f(0.8,0.8,0);
    glVertex2f(1,-1);
    glColor3f(0,0.50,0.0);
    glVertex2f(-1,-1);
    glEnd();
//brown circle

//Stones
    glColor3f(0.67,0.67,0.67);
    draw_circle(0.73,-0.86,0.07);
    glColor3f(0.67,0.67,0.67);
    draw_circle(0.89,-0.86,0.07);
    glColor3f(0.7,0.7,0.7);
    draw_circle(0.8,-0.88,0.05);
    glColor3f(0.7,0.7,0.7);
    draw_circle(1,-0.88,0.09);
    glColor3f(0.72,0.72,0.72);
    draw_circle(0.8,-1,0.09);
    glColor3f(0.75,0.75,0.75);
    draw_circle(0.92,-0.95,0.09);
    glColor3f(0.58,0.6,0.6);
    draw_circle(0.6,-0.8,0.03);
    glColor3f(0.58,0.6,0.6);
    draw_circle(0.58,-0.8,0.03);
    glColor3f(0.75,0.75,0.75);
    draw_circle(0.62,-0.88,0.09);

    glColor3f(0.67,0.67,0.67);
    draw_circle(-0.73,-0.86,0.07);
    glColor3f(0.67,0.67,0.67);
    draw_circle(-0.89,-0.86,0.07);
    glColor3f(0.7,0.7,0.7);
    draw_circle(-0.8,-0.88,0.05);
    glColor3f(0.7,0.7,0.7);
    draw_circle(-1,-0.88,0.09);
    glColor3f(0.72,0.72,0.72);
    draw_circle(-0.8,-1,0.09);
    glColor3f(0.75,0.75,0.75);
    draw_circle(-0.92,-0.95,0.09);


////----------------cloud
    glColor3f(1.0,1.0,1.0);
    draw_circle(q+0.7f, 0.9f, 0.05f);
    draw_circle(q+0.65f, 0.85f, 0.05f);
    draw_circle(q+0.75f, 0.8f, 0.05f);
    draw_circle(q+0.65f, 0.8f, 0.05f);
    draw_circle(q+0.7f, 0.85f, 0.05f);

    draw_circle(p-0.5f, 0.7f, 0.05f);
    draw_circle(p-0.45f, 0.65f, 0.05f);
    draw_circle(p-0.55f, 0.6f, 0.05f);
    draw_circle(p-0.45f, 0.6f, 0.05f);
    draw_circle(p-0.5f, 0.65f, 0.05f);
    draw_circle(p-0.6f, 0.7f, 0.08f);

    draw_circle(q+0.3f, 0.7f, 0.05f);
    draw_circle(q+0.35f, 0.75f, 0.05f);
    draw_circle(q+0.25f, 0.7f, 0.05f);
    draw_circle(q+0.35f, 0.7f, 0.05f);
    draw_circle(q+0.3f, 0.75f, 0.05f);
    draw_circle(q+0.2f, 0.8f, 0.08f);

    draw_circle(r-0.1f, 0.9f, 0.05f);
    draw_circle(r-0.15f, 0.85f, 0.05f);
    draw_circle(r-0.05f, 0.8f, 0.05f);
    draw_circle(r-0.15f, 0.8f, 0.05f);
    draw_circle(r-0.1f, 0.85f, 0.05f);

    glEnd();

//-----------------------Phineas
//eyes
    glColor3f(1.0,1.0,1.0);
    draw_circle(-0.63f, -0.187f, 0.025f);
    glColor3f(0.0,0.0,1.0);
    draw_circle(-0.63f, -0.187f, 0.01f);
    glColor3f(1.0,1.0,1.0);
    draw_circle(-0.63f, -0.187f, 0.002f);

    glBegin(GL_TRIANGLES);
//peach
    glColor3f(1,0.85,0.72);
    glVertex2f(-0.7,-0.18);
    glVertex2f(-0.65,-0.3);
    glVertex2f(-0.55,-0.2);
    glEnd();

//hair
    glBegin(GL_TRIANGLES);
//red
    glColor3f(1,0.27,0);
    glVertex2f(-0.7,-0.18);
    glVertex2f(-0.69,-0.2);
    glVertex2f(-0.73,-0.12);
    glEnd();
    glBegin(GL_TRIANGLES);
//red
    glColor3f(1,0.27,0);
    glVertex2f(-0.7,-0.20);
    glVertex2f(-0.69,-0.18);
    glVertex2f(-0.73,-0.14);
    glEnd();

    glBegin(GL_TRIANGLES);
//red
    glColor3f(1,0.27,0);
    glVertex2f(-0.73,-0.21);
    glVertex2f(-0.7,-0.16);
    glVertex2f(-0.65,-0.15);
    glEnd();

    glBegin(GL_TRIANGLES);
//red
    glColor3f(1,0.27,0);
    glVertex2f(-0.73,-0.23);
    glVertex2f(-0.7,-0.13);
    glVertex2f(-0.68,-0.15);
    glEnd();


//eyes
    glColor3f(1.0,1.0,1.0);
    draw_circle(-0.65f, -0.19f, 0.025f);
    glColor3f(0.0,0.0,1.0);
    draw_circle(-0.65f, -0.19f, 0.01f);
    glColor3f(1.0,1.0,1.0);
    draw_circle(-0.65f, -0.19f, 0.002f);


//lips
    glBegin(GL_QUADS);
//black
    glColor3f(0,0,0);
    glVertex2f(-0.64,-0.25);
    glVertex2f(-0.62,-0.27);
    glVertex2f(-0.62,-0.26);
    glVertex2f(-0.64,-0.24);
    glEnd();
//dress
    glBegin(GL_QUADS);
//orange
    glColor3f(1,0.58,0);
    glVertex2f(-0.67,-0.5);
    glVertex2f(-0.58,-0.5);
    glVertex2f(-0.63,-0.29);
    glVertex2f(-0.66,-0.29);
    glEnd();

    glBegin(GL_QUADS);
//yellow
    glColor3f(1,0.88,0);
    glVertex2f(-0.67,-0.5);
    glVertex2f(-0.58,-0.5);
    glVertex2f(-0.59,-0.47);
    glVertex2f(-0.668,-0.47);
    glEnd();

    glBegin(GL_QUADS);
//yellow
    glColor3f(1,0.88,0);
    glVertex2f(-0.67,-0.44);
    glVertex2f(-0.592,-0.44);
    glVertex2f(-0.601,-0.41);
    glVertex2f(-0.668,-0.41);
    glEnd();

    glBegin(GL_QUADS);
//yellow
    glColor3f(1,0.88,0);
    glVertex2f(-0.666,-0.37);
    glVertex2f(-0.61,-0.37);
    glVertex2f(-0.621,-0.34);
    glVertex2f(-0.66,-0.34);
    glEnd();

    glBegin(GL_QUADS);
//yellow
    glColor3f(1,0.88,0);
    glVertex2f(-0.66,-0.31);
    glVertex2f(-0.623,-0.31);
    glVertex2f(-0.63,-0.29);
    glVertex2f(-0.66,-0.29);
    glEnd();

     glBegin(GL_QUADS);
//yellow
    glColor3f(1,0.88,0);
    glVertex2f(-0.66,-0.31);
    glVertex2f(-0.623,-0.31);
    glVertex2f(-0.63,-0.29);
    glVertex2f(-0.66,-0.29);
    glEnd();

    glBegin(GL_QUADS);
//orange
    glColor3f(1,0.58,0);
    glVertex2f(-0.659,-0.295);
    glVertex2f(-0.629,-0.295);
    glVertex2f(-0.63,-0.29);
    glVertex2f(-0.66,-0.29);
    glEnd();


    glBegin(GL_QUADS);
//blue
    glColor3f(0,0,1);
    glVertex2f(-0.665,-0.6);
    glVertex2f(-0.585,-0.6);
    glVertex2f(-0.58,-0.5);
    glVertex2f(-0.67,-0.5);
    glEnd();

    glBegin(GL_LINE_STRIP);
//black pant lines
    glColor3f(0,0,0);
    glVertex2f(-0.665,-0.6);
    glVertex2f(-0.6,-0.6);
    glVertex2f(-0.6,-0.5);
    glVertex2f(-0.67,-0.5);
    glEnd();
    glBegin(GL_LINE_STRIP);
    glColor3f(0,0,0);
    glVertex2f(-0.6,-0.6);
    glVertex2f(-0.585,-0.6);
    glVertex2f(-0.58,-0.5);
    glVertex2f(-0.6,-0.5);
    glEnd();


//hands

//peach
    glPushMatrix();

    glTranslatef(tx,ty,0);
    glBegin(GL_QUADS);
    glColor3f(1,0.85,0.72);
    glVertex2f(-0.65,-0.37);
    glVertex2f(-0.58,-0.37);
    glVertex2f(-0.58,-0.35);
    glVertex2f(-0.65,-0.35);
    glEnd();
    glPopMatrix();


//grey
    glPushMatrix();

    glTranslatef(tx,ty,0);
    glBegin(GL_LINE_STRIP);
    glColor3f(0.77,0.77,0.66);
    glVertex2f(-0.64,-0.37);
    glVertex2f(-0.58,-0.37);
    glVertex2f(-0.58,-0.35);
    glVertex2f(-0.64,-0.35);
    glEnd();
    glPopMatrix();
//orange
    glPushMatrix();

    glTranslatef(tx,ty,0);
    glBegin(GL_LINE_STRIP);
    glColor3f(0.86,0.33,0);
    glVertex2f(-0.65,-0.39);
    glVertex2f(-0.64,-0.38);
    glVertex2f(-0.64,-0.34);
    glVertex2f(-0.65,-0.33);
    glEnd();
    glPopMatrix();
//legs

//blue
    glColor3f(1,1,1);
    draw_circle(-0.64f,-0.71f, 0.025f);
    draw_circle(-0.6f,-0.71f, 0.025f);
    glColor3f(0,0,1);
    draw_circle(-0.64f,-0.7f, 0.025f);
    draw_circle(-0.6f,-0.7f, 0.025f);

    glBegin(GL_QUADS);
//peach
    glColor3f(1,0.85,0.72);
    glVertex2f(-0.655,-0.7);
    glVertex2f(-0.638,-0.7);
    glVertex2f(-0.625,-0.6);
    glVertex2f(-0.65,-0.6);
    glEnd();

    glBegin(GL_QUADS);
//peach
    glColor3f(1,0.85,0.72);
    glVertex2f(-0.615,-0.7);
    glVertex2f(-0.598,-0.7);
    glVertex2f(-0.585,-0.6);
    glVertex2f(-0.61,-0.6);
    glEnd();
//wrist

    glPushMatrix();

    glTranslatef(tx,ty,0);
    glBegin(GL_QUADS);
    glColor3f(1,0.85,0.72);
    glVertex2f(-0.58,-0.375);
    glVertex2f(-0.572,-0.375);
    glVertex2f(-0.572,-0.348);
    glVertex2f(-0.58,-0.348);
    glEnd();
    glPopMatrix();

    glColor3f(1,0.85,0.72);
    draw_circle(-0.68f, -0.22f, 0.016f);

//--------------------------------saw

    glPushMatrix();

    glTranslatef(tx,ty,0);
    glBegin(GL_QUADS);
    glColor3f(0.54,0.22,0.22);
    glVertex2f(-0.57,-0.4);
    glVertex2f(-0.54,-0.4);
    glVertex2f(-0.54,-0.32);
    glVertex2f(-0.57,-0.32);
    glEnd();
    glPopMatrix();

    glPushMatrix();

    glTranslatef(tx,ty,0);
    glBegin(GL_QUADS);
    glColor3f(0,0.7080,0.0);
    glVertex2f(-0.56,-0.39);
    glVertex2f(-0.55,-0.39);
    glVertex2f(-0.55,-0.33);
    glVertex2f(-0.56,-0.33);
    glEnd();
    glPopMatrix();

    glPushMatrix();

    glTranslatef(tx,ty,0);
    glBegin(GL_QUADS);
    glColor3f(1,1,1);
    glVertex2f(-0.54,-0.4);
    glColor3f(1,1,1);
    glVertex2f(-0.04,-0.4);
    glColor3f(0.6,0.6,0.6);
    glVertex2f(-0.04,-0.32);
    glColor3f(0.6,0.6,0.6);
    glVertex2f(-0.54,-0.32);
    glEnd();
    glPopMatrix();

    glPushMatrix();

    glTranslatef(tx,ty,0);
    glBegin(GL_QUADS);
    glColor3f(0.54,0.22,0.22);
    glVertex2f(-0.04,-0.4);
    glVertex2f(-0.01,-0.4);
    glVertex2f(-0.01,-0.32);
    glVertex2f(-0.04,-0.32);
    glEnd();
    glPopMatrix();

    glPushMatrix();

    glTranslatef(tx,ty,0);
    glBegin(GL_QUADS);
    glColor3f(0,0.7080,0.0);
    glVertex2f(-0.03,-0.39);
    glVertex2f(-0.02,-0.39);
    glVertex2f(-0.02,-0.33);
    glVertex2f(-0.03,-0.33);
    glEnd();
    glPopMatrix();

    glPushMatrix();

    glTranslatef(tx,ty,0);
    glBegin(GL_TRIANGLES);
    glColor3f(1,1,1);
    glVertex2f(-0.07,-0.40);
    glVertex2f(-0.06,-0.42);
    glVertex2f(-0.05,-0.4);
    glEnd();
    glBegin(GL_TRIANGLES);
    glColor3f(1,1,1);
    glVertex2f(-0.1,-0.40);
    glVertex2f(-0.09,-0.42);
    glVertex2f(-0.08,-0.4);
    glEnd();
    glBegin(GL_TRIANGLES);
    glColor3f(1,1,1);
    glVertex2f(-0.13,-0.40);
    glVertex2f(-0.12,-0.42);
    glVertex2f(-0.11,-0.4);
    glEnd();
    glBegin(GL_TRIANGLES);
    glColor3f(1,1,1);
    glVertex2f(-0.16,-0.40);
    glVertex2f(-0.15,-0.42);
    glVertex2f(-0.14,-0.4);
    glEnd();
    glBegin(GL_TRIANGLES);
    glColor3f(1,1,1);
    glVertex2f(-0.19,-0.40);
    glVertex2f(-0.18,-0.42);
    glVertex2f(-0.17,-0.4);
    glEnd();
    glBegin(GL_TRIANGLES);
    glColor3f(1,1,1);
    glVertex2f(-0.22,-0.40);
    glVertex2f(-0.21,-0.42);
    glVertex2f(-0.20,-0.4);
    glEnd();
    glBegin(GL_TRIANGLES);
    glColor3f(1,1,1);
    glVertex2f(-0.25,-0.40);
    glVertex2f(-0.24,-0.42);
    glVertex2f(-0.23,-0.4);
    glEnd();
    glBegin(GL_TRIANGLES);
    glColor3f(1,1,1);
    glVertex2f(-0.28,-0.40);
    glVertex2f(-0.27,-0.42);
    glVertex2f(-0.26,-0.4);
    glEnd();
    glBegin(GL_TRIANGLES);
    glColor3f(1,1,1);
    glVertex2f(-0.31,-0.40);
    glVertex2f(-0.30,-0.42);
    glVertex2f(-0.29,-0.4);
    glEnd();
    glBegin(GL_TRIANGLES);
    glColor3f(1,1,1);
    glVertex2f(-0.34,-0.40);
    glVertex2f(-0.33,-0.42);
    glVertex2f(-0.32,-0.4);
    glEnd();
    glBegin(GL_TRIANGLES);
    glColor3f(1,1,1);
    glVertex2f(-0.37,-0.40);
    glVertex2f(-0.36,-0.42);
    glVertex2f(-0.35,-0.4);
    glEnd();
    glBegin(GL_TRIANGLES);
    glColor3f(1,1,1);
    glVertex2f(-0.40,-0.40);
    glVertex2f(-0.39,-0.42);
    glVertex2f(-0.38,-0.4);
    glEnd();
    glBegin(GL_TRIANGLES);
    glColor3f(1,1,1);
    glVertex2f(-0.43,-0.40);
    glVertex2f(-0.42,-0.42);
    glVertex2f(-0.41,-0.4);
    glEnd();
    glBegin(GL_TRIANGLES);
    glColor3f(1,1,1);
    glVertex2f(-0.46,-0.40);
    glVertex2f(-0.45,-0.42);
    glVertex2f(-0.44,-0.4);
    glEnd();
    glBegin(GL_TRIANGLES);
    glColor3f(1,1,1);
    glVertex2f(-0.49,-0.40);
    glVertex2f(-0.48,-0.42);
    glVertex2f(-0.47,-0.4);
    glEnd();
    glBegin(GL_TRIANGLES);
    glColor3f(1,1,1);
    glVertex2f(-0.52,-0.40);
    glVertex2f(-0.51,-0.42);
    glVertex2f(-0.50,-0.4);
    glEnd();

    glPopMatrix();

//------------------------------Robot

    glBegin(GL_QUADS);
//paste
    glColor3f(0.18,0.54,0.18);
    glVertex2f(b-0.44,-0.6);
    glVertex2f(b-0.14,-0.6);
    glVertex2f(b-0.14,0.2);
    glVertex2f(b-0.44,0.2);
    glEnd();
    glBegin(GL_LINE_STRIP);
//paste
    glColor3f(0.28,0.64,0.28);
    glVertex2f(-0.44,-0.6);
    glVertex2f(-0.14,-0.6);
    glVertex2f(-0.14,-0.07);
    glVertex2f(-0.44,-0.07);
    glVertex2f(-0.44,-0.07);
    glVertex2f(-0.44,-0.6);
    glEnd();

    glBegin(GL_QUADS);
//paste
    glColor3f(0.62,0.62,0.62);
    glVertex2f(-0.39,-0.75);
    glVertex2f(-0.35,-0.75);
    glColor3f(1,1,1);
    glVertex2f(-0.35,-0.59);
    glVertex2f(-0.39,-0.59);
    glEnd();
//paste
    glBegin(GL_QUADS);
    glColor3f(0.62,0.62,0.62);
    glVertex2f(-0.24,-0.75);
    glVertex2f(-0.20,-0.75);
    glColor3f(1,1,1);
    glVertex2f(-0.20,-0.59);
    glVertex2f(-0.24,-0.59);
    glEnd();
    glBegin(GL_QUADS);
    glColor3f(0.18,0.54,0.18);
    glVertex2f(-0.14,-0.3);
    glVertex2f(-0.09,-0.3);
    glVertex2f(-0.09,-0.02);
    glVertex2f(-0.14,-0.02);
    glEnd();
    glBegin(GL_QUADS);
    glColor3f(1,0.58,0);
    glVertex2f(-0.14,-0.35);
    glVertex2f(-0.07,-0.35);
    glVertex2f(-0.07,-0.3);
    glVertex2f(-0.14,-0.3);
    glEnd();

    glColor3f(0.58,0.58,0.58);
    draw_circle(-0.22f, -0.65f, 0.02f);
    glColor3f(0,0,0);
    draw_circle(-0.22f, -0.65f, 0.01f);
    glColor3f(0.58,0.58,0.58);
    draw_circle(-0.37f, -0.65f, 0.02f);
    glColor3f(0,0,0);
    draw_circle(-0.37f, -0.65f, 0.01f);

    glColor3f(0.58,0.58,0.58);
    draw_circle(-0.115f, -0.23f, 0.023f);
    glColor3f(0,0,0);
    draw_circle(-0.115, -0.23f, 0.01f);
    glColor3f(0.58,0.58,0.58);
    draw_circle(-0.115f, -0.04f, 0.023f);
    glColor3f(0,0,0);
    draw_circle(-0.115, -0.04f, 0.01f);

    glBegin(GL_TRIANGLES);
    glColor3f(1,0.58,0);
    glVertex2f(-0.14,-0.35);
    glVertex2f(-0.11,-0.39);
    glVertex2f(-0.11,-0.35);
    glEnd();
    glBegin(GL_TRIANGLES);
    glColor3f(1,0.58,0);
    glVertex2f(-0.09,-0.35);
    glVertex2f(-0.09,-0.39);
    glVertex2f(-0.07,-0.35);
    glEnd();
//orange
    glBegin(GL_TRIANGLES);
    glColor3f(1,0.58,0);
    glVertex2f(-0.22,-0.72);
    glVertex2f(-0.27,-0.78);
    glVertex2f(-0.17,-0.78);
    glEnd();
    glBegin(GL_TRIANGLES);
    glColor3f(1,0.58,0);
    glVertex2f(-0.37,-0.72);
    glVertex2f(-0.42,-0.78);
    glVertex2f(-0.32,-0.78);
    glEnd();
//glass window

    glBegin(GL_QUADS);
    glColor3f(0.62,0.62,0.62);
    glVertex2f(-0.4,0.05);
    glVertex2f(-0.3,0.05);
    glColor3f(1,1,1);
    glVertex2f(-0.3,0.17);
    glVertex2f(-0.4,0.17);
    glEnd();
    glBegin(GL_QUADS);
    glColor3f(0.62,0.62,0.62);
    glVertex2f(-0.28,0.05);
    glVertex2f(-0.18,0.05);
    glColor3f(1,1,1);
    glVertex2f(-0.18,0.17);
    glVertex2f(-0.28,0.17);
    glEnd();
    glBegin(GL_QUADS);
    glColor3f(1,0.58,0);
    glVertex2f(-0.28,0.05);
    glVertex2f(-0.18,0.05);
    glVertex2f(-0.18,0.07);
    glVertex2f(-0.28,0.07);
    glEnd();
    glBegin(GL_QUADS);
    glColor3f(1,0.58,0);
    glVertex2f(-0.28,0.15);
    glVertex2f(-0.18,0.15);
    glVertex2f(-0.18,0.17);
    glVertex2f(-0.28,0.17);
    glEnd();
    glBegin(GL_QUADS);
    glColor3f(1,0.58,0);
    glVertex2f(-0.28,0.05);
    glVertex2f(-0.26,0.05);
    glVertex2f(-0.26,0.17);
    glVertex2f(-0.28,0.17);
    glEnd();
    glBegin(GL_QUADS);
    glColor3f(1,0.58,0);
    glVertex2f(-0.20,0.05);
    glVertex2f(-0.18,0.05);
    glVertex2f(-0.18,0.17);
    glVertex2f(-0.20,0.17);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(1,0.58,0);
    glVertex2f(-0.4,0.05);
    glVertex2f(-0.3,0.05);
    glVertex2f(-0.3,0.07);
    glVertex2f(-0.4,0.07);
    glEnd();
    glBegin(GL_QUADS);
    glColor3f(1,0.58,0);
    glVertex2f(-0.4,0.15);
    glVertex2f(-0.3,0.15);
    glVertex2f(-0.3,0.17);
    glVertex2f(-0.4,0.17);
    glEnd();
    glBegin(GL_QUADS);
    glColor3f(1,0.58,0);
    glVertex2f(-0.4,0.05);
    glVertex2f(-0.38,0.05);
    glVertex2f(-0.38,0.17);
    glVertex2f(-0.4,0.17);
    glEnd();
    glBegin(GL_QUADS);
    glColor3f(1,0.58,0);
    glVertex2f(-0.32,0.05);
    glVertex2f(-0.30,0.05);
    glVertex2f(-0.30,0.17);
    glVertex2f(-0.32,0.17);
    glEnd();


    glBegin(GL_QUADS);
    glColor3f(0.62,0.62,0.62);
    glVertex2f(-0.4,-0.55);
    glVertex2f(-0.25,-0.55);
    glColor3f(1,1,1);
    glVertex2f(-0.25,-0.40);
    glVertex2f(-0.4,-0.40);
    glEnd();
    glBegin(GL_LINE_STRIP);
    glColor3f(0,0,0);
    glVertex2f(-0.4,-0.55);
    glVertex2f(-0.25,-0.55);
    glVertex2f(-0.25,-0.40);
    glVertex2f(-0.4,-0.40);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(1,0,0);
    glVertex2f(-0.38,-0.47);
    glVertex2f(-0.34,-0.47);
    glVertex2f(-0.34,-0.42);
    glVertex2f(-0.38,-0.42);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(1,1,0);
    glVertex2f(-0.32,-0.45);
    glVertex2f(-0.27,-0.45);
    glVertex2f(-0.27,-0.42);
    glVertex2f(-0.32,-0.42);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(1,0.58,0);
    glVertex2f(-0.38,-0.54);
    glVertex2f(-0.27,-0.54);
    glVertex2f(-0.27,-0.52);
    glVertex2f(-0.38,-0.52);
    glEnd();

     glColor3f(0.58,0,0.83);
     draw_circle(-0.34,-0.495,0.02);
     glColor3f(0.85,0.47,0.84);
     draw_circle(-0.31,-0.495,0.02);
     glColor3f(1,0.68,0.72);
     draw_circle(-0.28,-0.495,0.02);

//--------------------------------Ferb
     glBegin(GL_QUADS);
//peach
    glColor3f(1,0.85,0.72);
    glVertex2f(0.05,-0.3);
    glVertex2f(0.1,-0.3);
    glVertex2f(0.11,-0.1);
    glVertex2f(0.03,-0.1);
    glEnd();
    glColor3f(1,0.85,0.72);
    draw_circle(0.105,-0.18,0.015);
//hair green
     glBegin(GL_TRIANGLES);
    glColor3f(0,0.65,0);
    glVertex2f(0.04,-0.07);
    glVertex2f(0.11,-0.1);
    glVertex2f(-0.02,-0.12);
    glEnd();
     glBegin(GL_TRIANGLES);
    glColor3f(0,0.65,0);
    glVertex2f(0.04,-0.1);
    glVertex2f(0.11,-0.08);
    glVertex2f(0.01,-0.07);
    glEnd();
     glBegin(GL_TRIANGLES);
    glColor3f(0,0.65,0);
    glVertex2f(0.08,-0.04);
    glVertex2f(0.11,-0.1);
    glVertex2f(0.08,-0.14);
    glEnd();
     glBegin(GL_TRIANGLES);
    glColor3f(0,0.65,0);
    glVertex2f(0.11,-0.07);
    glVertex2f(0.08,-0.1);
    glVertex2f(0.12,-0.12);
    glEnd();
     glBegin(GL_QUADS);
//cream
    glColor3f(1,0.93,0.55);
    glVertex2f(0.05,-0.39);
    glVertex2f(0.1,-0.39);
    glVertex2f(0.1,-0.3);
    glVertex2f(0.05,-0.3);
    glEnd();


    glPushMatrix();

    glTranslatef(tx,ty,0);
    glBegin(GL_QUADS);
    glColor3f(1,0.85,0.72);
    glVertex2f(0.07,-0.35);
    glVertex2f(-0.01,-0.35);
    glVertex2f(-0.01,-0.33);
    glVertex2f(0.07,-0.33);
    glEnd();
    glPopMatrix();
    glPushMatrix();

    glTranslatef(tx,ty,0);
    glBegin(GL_QUADS);
    glColor3f(1,0.93,0.55);
    glVertex2f(0.07,-0.37);
    glVertex2f(0.02,-0.37);
    glVertex2f(0.02,-0.32);
    glVertex2f(0.07,-0.32);
    glEnd();
    glPopMatrix();

    glBegin(GL_QUADS);
    glColor3f(1,0.93,0.55);
    glVertex2f(0.12,-0.37);
    glVertex2f(0.1,-0.37);
    glVertex2f(0.1,-0.32);
    glVertex2f(0.12,-0.32);
    glEnd();

    glBegin(GL_QUADS);
    glColor3f(1,0.85,0.72);
    glVertex2f(0.115,-0.43);
    glVertex2f(0.105,-0.43);
    glVertex2f(0.105,-0.37);
    glVertex2f(0.115,-0.37);
    glEnd();
    glColor3f(1,0.85,0.72);
    draw_circle(0.11,-0.44,0.01);
     glBegin(GL_TRIANGLES);
    glColor3f(1,1,1);
    glVertex2f(0.04,-0.3);
    glVertex2f(0.08,-0.3);
    glVertex2f(0.06,-0.35);
    glEnd();
     glBegin(GL_TRIANGLES);
    glColor3f(1,1,1);
    glVertex2f(0.06,-0.3);
    glVertex2f(0.11,-0.3);
    glVertex2f(0.09,-0.35);
    glEnd();
//pant
     glBegin(GL_QUADS);
//purple
    glColor3f(0.5,0,0.5);
    glVertex2f(0.05,-0.39);
    glVertex2f(0.1,-0.39);
    glVertex2f(0.1,-0.55);
    glVertex2f(0.05,-0.55);
    glEnd();
    glColor3f(0.5,0,0.5);
    draw_circle(0.075,-0.55,0.023);
     glBegin(GL_QUADS);
//purple
    glColor3f(0.5,0,0.5);
    glVertex2f(0.057,-0.55);
    glVertex2f(0.073,-0.55);
    glVertex2f(0.073,-0.62);
    glVertex2f(0.057,-0.62);
    glEnd();
     glBegin(GL_QUADS);
//purple
    glColor3f(0.5,0,0.5);
    glVertex2f(0.078,-0.55);
    glVertex2f(0.095,-0.55);
    glVertex2f(0.095,-0.62);
    glVertex2f(0.078,-0.62);
    glEnd();
     glBegin(GL_QUADS);
//peach
    glColor3f(1,0.85,0.72);
    glVertex2f(0.057,-0.62);
    glVertex2f(0.073,-0.62);
    glVertex2f(0.073,-0.68);
    glVertex2f(0.057,-0.68);
    glEnd();
     glBegin(GL_QUADS);
//peach
    glColor3f(1,0.85,0.72);
    glVertex2f(0.078,-0.62);
    glVertex2f(0.095,-0.62);
    glVertex2f(0.095,-0.68);
    glVertex2f(0.078,-0.68);
    glEnd();
    glColor3f(1,1,1);
    draw_circle(0.082,-0.679,0.02);
    glColor3f(1,1,1);
    draw_circle(0.062,-0.679,0.02);
    glColor3f(0,0,0);
    draw_circle(0.082,-0.67,0.02);
    glColor3f(0,0,0);
    draw_circle(0.062,-0.67,0.02);
//eyes
    glColor3f(1.0,1.0,1.0);
    draw_circle(0.039f, -0.15f, 0.02f);
    glColor3f(0.0,0.0,1.0);
    draw_circle(0.039f, -0.15f, 0.0075f);
    glColor3f(1.0,1.0,1.0);
    draw_circle(0.039f, -0.15f, 0.002f);
    glColor3f(1.0,1.0,1.0);
    draw_circle(0.059f, -0.152f, 0.013f);
    glColor3f(0.0,0.0,1.0);
    draw_circle(0.059f, -0.152f, 0.007f);
    glColor3f(1.0,1.0,1.0);
    draw_circle(0.059f, -0.152f, 0.002f);
     glBegin(GL_QUADS);
//peach
    glColor3f(1,0.85,0.72);
    glVertex2f(0.04,-0.28);
    glVertex2f(0.08,-0.28);
    glVertex2f(0.08,-0.25);
    glVertex2f(0.05,-0.25);
    glEnd();
     glBegin(GL_QUADS);
//peach
    glColor3f(1,0.85,0.72);
    glVertex2f(0.02,-0.23);
    glVertex2f(0.08,-0.23);
    glVertex2f(0.08,-0.17);
    glVertex2f(0.02,-0.17);
    glEnd();
//-------------------pet house
      glBegin(GL_POLYGON);
//offwhite
    glColor3f(1,0.98,0.8);
    glVertex2f(0.72,-0.29);
    glVertex2f(0.72,-0.61);
    glVertex2f(1,-0.61);
    glVertex2f(1,-0.29);
    glEnd();
      glBegin(GL_POLYGON);
//grey
    glColor3f(0.95,0.95,0.95);
    glVertex2f(0.8,-0.35);
    glVertex2f(0.8,-0.55);
    glColor3f(1,1,1);
    glVertex2f(0.95,-0.55);
    glVertex2f(0.95,-0.35);
    glEnd();

//------------------------------------------------perry

     glBegin(GL_QUADS);
//paste
    glColor3f(0.18,0.54,0.18);
    glVertex2f(a+0.6,-0.55);
    glVertex2f(a+0.8,-0.55);
    glVertex2f(a+0.8,-0.44);
    glVertex2f(a+0.6,-0.44);
    glEnd();
     glBegin(GL_QUADS);
//orange
    glColor3f(1,0.58,0);
    glVertex2f(a+0.8,-0.53);
    glVertex2f(a+0.87,-0.53);
    glVertex2f(a+0.86,-0.44);
    glVertex2f(a+0.8,-0.46);
    glEnd();
     glBegin(GL_QUADS);
//paste
    glColor3f(0.18,0.54,0.18);
    glVertex2f(a+0.62,-0.58);
    glVertex2f(a+0.64,-0.58);
    glVertex2f(a+0.64,-0.55);
    glVertex2f(a+0.62,-0.55);
    glEnd();
     glBegin(GL_QUADS);
//paste
    glColor3f(0.18,0.54,0.18);
    glVertex2f(a+0.65,-0.59);
    glVertex2f(a+0.67,-0.59);
    glVertex2f(a+0.67,-0.55);
    glVertex2f(a+0.65,-0.55);
    glEnd();
    glColor3f(1,0.58,0);
    draw_circle(a+0.66,-0.59,0.012);
    glColor3f(1,0.58,0);
    draw_circle(a+0.63,-0.58,0.012);

    glColor3f(1.0,1.0,1.0);
    draw_circle(a+0.63f, -0.48f, 0.015f);
    glColor3f(0.0,0.0,1.0);
    draw_circle(a+0.63f, -0.48f, 0.0075f);
    glColor3f(1.0,1.0,1.0);
    draw_circle(a+0.63f, -0.48f, 0.002f);
    glColor3f(1.0,1.0,1.0);
    draw_circle(a+0.60f, -0.48f, 0.012f);
    glColor3f(0.0,0.0,1.0);
    draw_circle(a+0.60f, -0.48f, 0.0075f);
    glColor3f(1.0,1.0,1.0);
    draw_circle(a+0.60f, -0.48f, 0.002f);
    glColor3f(1.0,1.0,1.0);

     glBegin(GL_TRIANGLES);
    glColor3f(1,0.58,0);
    glVertex2f(a+0.61,-0.504);
    glVertex2f(a+0.6,-0.535);
    glVertex2f(a+0.63,-0.52);
    glEnd();
     glBegin(GL_QUADS);
//orange
    glColor3f(1,0.58,0);
    glVertex2f(a+0.58,-0.533);
    glVertex2f(a+0.63,-0.533);
    glVertex2f(a+0.63,-0.52);
    glVertex2f(a+0.58,-0.52);
    glEnd();


//--------------------------------------------------
      glBegin(GL_POLYGON);
//offwhite
    glColor3f(1,0.98,0.8);
    glVertex2f(0.72,-0.29);
    glVertex2f(0.72,-0.61);
    glVertex2f(0.8,-0.61);
    glVertex2f(0.8,-0.29);
    glEnd();
      glBegin(GL_POLYGON);
//offwhite
    glColor3f(1,0.98,0.8);
    glVertex2f(0.95,-0.29);
    glVertex2f(0.95,-0.61);
    glVertex2f(1,-0.61);
    glVertex2f(1,-0.29);
    glEnd();
      glBegin(GL_POLYGON);
//offwhite
    glColor3f(1,0.98,0.8);
    glVertex2f(0.8,-0.55);
    glVertex2f(0.8,-0.61);
    glVertex2f(1,-0.61);
    glVertex2f(1,-0.55);
    glEnd();
     glBegin(GL_LINE_STRIP);
//grey
    glColor3f(0.75,0.75,0.75);
    glVertex2f(0.8,-0.35);
    glVertex2f(0.8,-0.55);
    glColor3f(1,1,1);
    glVertex2f(0.95,-0.55);
    glVertex2f(0.95,-0.35);
    glEnd();

      glBegin(GL_TRIANGLES);
//offwhite
    glColor3f(1,0.98,0.8);
    glVertex2f(0.72,-0.29);
    glVertex2f(1,-0.29);
    glVertex2f(0.9,-0.15);
    glEnd();
      glBegin(GL_QUADS);
//lavender
    glColor3f(0.58,0.44,0.86);
    glVertex2f(1,-0.20);
    glVertex2f(1,-0.29);
    glVertex2f(0.83,-0.1);
    glVertex2f(1,-0.07);
    glEnd();

      glBegin(GL_QUADS);
//lavender
    glColor3f(0.58,0.44,0.86);
    glVertex2f(0.7,-0.28);
    glVertex2f(0.7,-0.37);
    glVertex2f(0.9,-0.17);
    glVertex2f(0.9,-0.08);
    glEnd();
//--------------------drawing board


//------------------radio
//blue
    glColor3f(0,0,1);
    draw_circle(0.37,-0.55,0.012);
    glColor3f(0,0,1);
    draw_circle(0.4,-0.55,0.012);
    glColor3f(0,0,1);
    draw_circle(0.43,-0.55,0.012);
      glBegin(GL_QUADS);
//handle
    glColor3f(0.3,0.3,0.3);
    glVertex2f(0.33,-0.51);
    glVertex2f(0.33,-0.55);
    glVertex2f(0.34,-0.55);
    glVertex2f(0.34,-0.51);
    glEnd();
      glBegin(GL_QUADS);
//handle
    glColor3f(0.3,0.3,0.3);
    glVertex2f(0.46,-0.51);
    glVertex2f(0.46,-0.55);
    glVertex2f(0.47,-0.55);
    glVertex2f(0.47,-0.51);
    glEnd();
      glBegin(GL_QUADS);
//handle
    glColor3f(0.3,0.3,0.3);
    glVertex2f(0.33,-0.50);
    glVertex2f(0.33,-0.51);
    glVertex2f(0.47,-0.51);
    glVertex2f(0.47,-0.50);
    glEnd();
      glBegin(GL_QUADS);
//maroon
    glColor3f(0.8,0,0);
    glVertex2f(0.25,b-0.55);
    glVertex2f(0.25,b-0.75);
    glVertex2f(0.55,b-0.75);
    glVertex2f(0.55,b-0.55);
    glEnd();
      glBegin(GL_QUADS);
//grey
    glColor3f(0.3,0.3,0.3);
    glVertex2f(0.27,-0.57);
    glVertex2f(0.27,-0.73);
    glVertex2f(0.34,-0.73);
    glVertex2f(0.34,-0.57);
    glEnd();
      glBegin(GL_QUADS);
//grey
    glColor3f(0.3,0.3,0.3);
    glVertex2f(0.46,-0.57);
    glVertex2f(0.46,-0.73);
    glVertex2f(0.53,-0.73);
    glVertex2f(0.53,-0.57);
    glEnd();
      glBegin(GL_QUADS);
//blue
    glColor3f(0,0,1);
    glVertex2f(0.35,-0.63);
    glVertex2f(0.35,-0.73);
    glVertex2f(0.45,-0.73);
    glVertex2f(0.45,-0.63);
    glEnd();
      glBegin(GL_QUADS);
//grey
    glColor3f(0.3,0.3,0.3);
    glVertex2f(0.36,-0.65);
    glVertex2f(0.36,-0.69);
    glVertex2f(0.44,-0.69);
    glVertex2f(0.44,-0.65);
    glEnd();

//yellow
    glColor3f(1,1,0);
    draw_circle(0.37,-0.59,0.012);
    glColor3f(1,1,0);
    draw_circle(0.4,-0.59,0.012);
    glColor3f(1,1,0);
    draw_circle(0.43,-0.59,0.012);

//must keep at the end
    glColor3f(1,0.58,0);
    glTranslatef(-0.30,-0.07,0);
    circle(0.04,0.03);
    glColor3f(1,0.58,0);
    glTranslatef(0.02,0.01,0);
    circle(0.05,0.02);
    glColor3f(1,0.58,0);
    glTranslatef(-0.02,0.01,0);
    circle(0.015,0.04);


    glFlush();
}

void spe_key(int key, int x, int y)
{

    switch (key)
    {

    case GLUT_KEY_LEFT:
        if(tx>=-0.005)
        {
            //PlaySound("Wood Saw-SoundBible.com-1996255876-[AudioTrimmer.com].wav", NULL, SND_FILENAME| SND_ASYNC);
            tx -=0.002;
        }

        glutPostRedisplay();
        break;

    case GLUT_KEY_RIGHT:
        if(tx<=0.02)
        {
            //PlaySound("Wood Saw-SoundBible.com-1996255876-[AudioTrimmer.com].wav", NULL, SND_FILENAME| SND_ASYNC);
            tx +=0.002;
        }

        glutPostRedisplay();
        break;

    default:
        break;
    }
}

int main()
{
    //PlaySound("Phineas and Ferb.wav", NULL, SND_FILENAME| SND_ASYNC| SND_LOOP);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize(1000, 600);
    glutInitWindowSize(1000, 600);
    glutInitWindowPosition(50, 50);
    glutCreateWindow("Phineas and Ferb");
    init();
    glutDisplayFunc(myDisplay);
    glutSpecialFunc(spe_key);
    glutMainLoop();
    return 0;
}
